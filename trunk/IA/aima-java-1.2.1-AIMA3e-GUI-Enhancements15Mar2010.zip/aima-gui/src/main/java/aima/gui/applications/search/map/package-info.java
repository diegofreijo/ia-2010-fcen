/**
 * This package contains useful components for building graphical map agent
 * applications and one example application.
 */
package aima.gui.applications.search.map;